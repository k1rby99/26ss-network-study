# mini-ids 만들기

패킷을 분석해서 Port Scan, ARP Spoofing, DNS Tunneling를 탐지 할 수 있는 mini ids 입니다.

## 실행

python3 mini_ids.py

## 제출 자료

- 테스트 PCAP : `pcaps/mini_ids_test.pcap`

* 테스트 PCAP은 `generate_test_pcap.py`로 생성한 실습용 패킷입니다.