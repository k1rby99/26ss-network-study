import argparse
from collections import defaultdict
from pathlib import Path

from scapy.all import ARP, DNS, DNSQR, ICMP, IP, Raw, TCP, rdpcap


PORT_SCAN_WINDOW = 10.0
PORT_SCAN_THRESHOLD = 20


class MiniIDS:
    def __init__(self, log_path):
        # (출발지 IP, 목적지 IP)별 최근 SYN 패킷의 (시각, 포트)
        self.syn_history = defaultdict(list)

        # 같은 포트 스캔 경고가 계속 반복되는 것을 방지
        self.scan_alerted = set()

        # ARP 패킷에서 관찰한 IP-MAC 대응 관계
        self.arp_table = {}

        self.log_path = Path(log_path)
        self.log_path.parent.mkdir(parents=True, exist_ok=True)

        # 매 실행마다 이번 분석 결과만 남깁니다.
        self.log_path.write_text("", encoding="utf-8")

    def emit(self, level, category, message):
        line = f"[{level}][{category}] {message}"
        print(line)

        with self.log_path.open("a", encoding="utf-8") as log_file:
            log_file.write(line + "\n")

    def detect_port_scan(self, packet):
        if IP not in packet or TCP not in packet:
            return

        flags = int(packet[TCP].flags)
        is_syn = bool(flags & 0x02)
        is_ack = bool(flags & 0x10)

        # 신규 연결을 시도하는 SYN만 검사합니다.
        if not is_syn or is_ack:
            return

        key = (packet[IP].src, packet[IP].dst)
        now = float(packet.time)
        destination_port = int(packet[TCP].dport)

        # 시간 창 안에 있는 이전 기록만 유지합니다.
        recent = [
            (seen_time, port)
            for seen_time, port in self.syn_history[key]
            if 0 <= now - seen_time <= PORT_SCAN_WINDOW
        ]

        recent.append((now, destination_port))
        self.syn_history[key] = recent

        unique_ports = {port for _, port in recent}

        if len(unique_ports) >= PORT_SCAN_THRESHOLD and key not in self.scan_alerted:
            self.scan_alerted.add(key)

            self.emit(
                "ALERT",
                "PORT_SCAN",
                f"출발지={key[0]}, 목적지={key[1]}, "
                f"{PORT_SCAN_WINDOW:g}초 내 서로 다른 포트={len(unique_ports)}개",
            )

    def detect_arp_spoofing(self, packet):
        if ARP not in packet or int(packet[ARP].op) != 2:
            return

        sender_ip = packet[ARP].psrc
        sender_mac = packet[ARP].hwsrc.lower()

        previous_mac = self.arp_table.get(sender_ip)

        if previous_mac is None:
            self.arp_table[sender_ip] = sender_mac
            return

        if previous_mac != sender_mac:
            self.emit(
                "ALERT",
                "ARP_SPOOFING",
                f"IP={sender_ip}, 기존 MAC={previous_mac}, "
                f"새 MAC={sender_mac}",
            )

            # 변경 사실을 기록하여 같은 패킷에 대한 반복 경고를 줄입니다.
            self.arp_table[sender_ip] = sender_mac

    def detect_special_packet(self, packet):
        if IP not in packet:
            return

        source = packet[IP].src
        destination = packet[IP].dst

        if DNS in packet and DNSQR in packet and int(packet[DNS].qr) == 0:
            domain = packet[DNSQR].qname.decode(
                "utf-8", errors="replace"
            ).rstrip(".")

            self.emit(
                "INFO",
                "DNS_QUERY",
                f"{source} → {destination}, 도메인={domain}",
            )

        if ICMP in packet and int(packet[ICMP].type) == 8:
            self.emit(
                "INFO",
                "ICMP_ECHO_REQUEST",
                f"{source} → {destination}, "
                f"id={packet[ICMP].id}, seq={packet[ICMP].seq}",
            )

        if TCP not in packet:
            return

        destination_port = int(packet[TCP].dport)
        flags = int(packet[TCP].flags)

        if destination_port == 22 and (flags & 0x02) and not (flags & 0x10):
            self.emit(
                "INFO",
                "SSH_CONNECTION_ATTEMPT",
                f"{source} → {destination}:22",
            )

        if destination_port == 80 and Raw in packet:
            payload = bytes(packet[Raw].load)

            if payload.startswith(b"GET "):
                first_line = payload.split(b"\r\n", 1)[0].decode(
                    "utf-8", errors="replace"
                )

                self.emit(
                    "INFO",
                    "HTTP_REQUEST",
                    f"{source} → {destination}:80, {first_line}",
                )

    def process_packet(self, packet):
        self.detect_port_scan(packet)
        self.detect_arp_spoofing(packet)
        self.detect_special_packet(packet)


def main():
    parser = argparse.ArgumentParser(description="3·4주차 Mini IDS")
    parser.add_argument("--pcap", required=True, help="분석할 PCAP 경로")
    parser.add_argument(
        "--log",
        default="logs/alerts.log",
        help="결과 로그 경로",
    )
    args = parser.parse_args()

    packets = rdpcap(args.pcap)
    ids = MiniIDS(args.log)

    print(f"분석 파일: {args.pcap}")
    print(f"패킷 수: {len(packets)}")

    for packet in packets:
        ids.process_packet(packet)

    print(f"분석 완료. 결과 로그: {args.log}")


if __name__ == "__main__":
    main()
