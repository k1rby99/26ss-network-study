from pathlib import Path

from scapy.all import ARP, DNS, DNSQR, Ether, ICMP, IP, Raw, TCP, UDP, wrpcap


OUTPUT = Path("pcaps/mini_ids_test.pcap")
OUTPUT.parent.mkdir(parents=True, exist_ok=True)

packets = []
base_time = 1_700_000_000.0


def add_packet(packet, seconds):
    # PCAP 분석 시 사용할 패킷 시각을 직접 지정합니다.
    packet.time = base_time + seconds
    packets.append(packet)


# 1. 정상 ARP Reply: 게이트웨이 IP의 최초 MAC을 기준으로 저장합니다.
add_packet(
    Ether(src="aa:aa:aa:aa:aa:aa", dst="ff:ff:ff:ff:ff:ff")
    / ARP(
        op=2,
        psrc="192.0.2.1",
        hwsrc="aa:aa:aa:aa:aa:aa",
        pdst="192.0.2.10",
    ),
    0.0,
)


# 2. DNS 질의
add_packet(
    Ether()
    / IP(src="192.0.2.10", dst="192.0.2.53")
    / UDP(sport=53000, dport=53)
    / DNS(rd=1, qd=DNSQR(qname="example.test")),
    0.2,
)


# 3. ICMP Echo Request
add_packet(
    Ether()
    / IP(src="192.0.2.10", dst="192.0.2.20")
    / ICMP(type=8, code=0, id=2026, seq=1)
    / Raw(load=b"HELLO-JW"),
    0.4,
)


# 4. HTTP GET 요청
add_packet(
    Ether()
    / IP(src="192.0.2.10", dst="192.0.2.80")
    / TCP(sport=51000, dport=80, flags="PA")
    / Raw(load=b"GET /index.html HTTP/1.1\r\nHost: example.test\r\n\r\n"),
    0.6,
)


# 5. SSH 연결 시도
add_packet(
    Ether()
    / IP(src="192.0.2.10", dst="192.0.2.22")
    / TCP(sport=51001, dport=22, flags="S"),
    0.8,
)


# 6. 동일 IP의 MAC이 변경된 ARP Reply
add_packet(
    Ether(src="cc:cc:cc:cc:cc:cc", dst="ff:ff:ff:ff:ff:ff")
    / ARP(
        op=2,
        psrc="192.0.2.1",
        hwsrc="cc:cc:cc:cc:cc:cc",
        pdst="192.0.2.10",
    ),
    1.0,
)


# 7. 10초 이내에 서로 다른 20개 포트로 향하는 TCP SYN
scan_ports = [
    21, 22, 23, 25, 53,
    80, 110, 135, 139, 143,
    443, 445, 993, 995, 1433,
    3306, 3389, 5432, 8080, 8443,
]

for index, port in enumerate(scan_ports):
    add_packet(
        Ether()
        / IP(src="192.0.2.50", dst="192.0.2.100")
        / TCP(sport=40000 + index, dport=port, flags="S"),
        2.0 + index * 0.2,
    )


wrpcap(str(OUTPUT), packets)
print(f"생성 완료: {OUTPUT}")
print(f"총 패킷 수: {len(packets)}")
