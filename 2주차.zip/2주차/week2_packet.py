from scapy.all import IP, ICMP, Raw, wrpcap

# 패킷 생성 함수
def make_packet(message):
    packet = (
        IP(
            src="192.0.2.10",
            dst="192.0.2.27",
            ttl=32,
            id=100
        )
        / ICMP(
            type=8,
            code=0,
            id=2026,
            seq=2
        )
        / Raw(
            load=message.encode()
        )
    )
    return packet

# 기본 패킷 생성
packet = make_packet("HELLO-JW")

print("=" * 60)
print("1. show() 결과")
print("=" * 60)

# 자동 계산 전 패킷 구조
packet.show()

print("\n" + "=" * 60)
print("2. show2() 결과")
print("=" * 60)

# Length와 Checksum을 계산한 패킷 구조
packet.show2()

# 비교 실험용 패킷
base_packet = make_packet("HELLO-JW")
same_length_packet = make_packet("HELLO-JX")
longer_packet = make_packet("HELLO-JW-2026")

def print_packet_result(name, original_packet):
    # 패킷을 실제 바이트로 만든 후 다시 분석
    calculated_packet = IP(bytes(original_packet))

    print(f"\n[{name}]")
    print(f"Payload        : {bytes(calculated_packet[Raw].load).decode()}")
    print(f"Payload Length : {len(calculated_packet[Raw].load)} bytes")
    print(f"IP Length      : {calculated_packet[IP].len}")
    print(f"IP Checksum    : {hex(calculated_packet[IP].chksum)}")
    print(f"ICMP Checksum  : {hex(calculated_packet[ICMP].chksum)}")


print("\n" + "=" * 60)
print("3. Payload 변경 비교")
print("=" * 60)

print_packet_result("기본 메시지", base_packet)
print_packet_result("동일 길이 메시지", same_length_packet)
print_packet_result("길이가 긴 메시지", longer_packet)


# 기본 패킷을 PCAP 파일로 저장
wrpcap("week2_packet.pcap", [
    base_packet,
    same_length_packet,
    longer_packet
])

print("\n" + "=" * 60)
print("week2_packet.pcap 저장 완료")
print("=" * 60)
